Hi,

This is free Subway set which you can use for non-commercial applications!
For commercial usage please buy full version included more formats and commercial license.

Subway is a set of over 300 pixel perfect crafted icons optimized for:
- Windows Phone 7/8 (48px and 72px)
- Windows 8 (40px)
- BlackBerry 10 (81px, 71px and 61px)
- iOS (30px and 60px)
- iOS 7 Style (60px)

Delivered in PNG, SVG*, XALM*, PSD*, AI* and EPS* format.

* only in full version

Full version is available on http://subway.pixle.pl for $9.99.

Questions & suggestions - subway@pixle.pl

Best
Pixle