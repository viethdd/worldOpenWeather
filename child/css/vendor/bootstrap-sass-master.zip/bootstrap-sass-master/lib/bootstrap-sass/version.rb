module Bootstrap
  VERSION = '3.1.1.1'
  BOOTSTRAP_SHA = '4aca4cf8661ab6e17ffd58820679a081db80ceaa'
end
